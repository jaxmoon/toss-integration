---
name: feature-impl
description: This skill orchestrates TDD-based feature development with GitHub Issues integration and parallel agent execution. Use when implementing features that require Test-Driven Development (Red-Green-Refactor cycles), GitHub issue tracking, and coordinated work across multiple specialized agents. Triggered by requests like "start [feature-name] feature", "continue [feature-name]", or when a techspec document exists for a new feature implementation.
---

# Feature Implementation Orchestrator

## Overview

Orchestrate complete feature development using Test-Driven Development (TDD) methodology with GitHub Issues integration and parallel specialized agent execution. This skill manages the entire lifecycle from techspec analysis to parallel task execution, automated issue tracking, and progress synchronization.

## When to Use This Skill

Use this skill when implementing features that require:
- **TDD methodology** - Red-Green-Refactor commit cycles for each task
- **GitHub issue tracking** - Centralized task management and progress visibility
- **Parallel development** - Multiple tasks executed simultaneously by specialized agents
- **Complex implementations** - Features with multiple components (frontend, backend, database, etc.)
- **Context preservation** - Ability to resume work across multiple sessions

**Typical triggers:**
- "Start [feature-name] feature"
- "Continue [feature-name]"
- "Resume work on [feature-name]"
- When a techspec file exists at `docs/features/{feature}/techspec.md`

## Preflight Requirements

**Before starting, verify these requirements:**

1. **Git repository with remote:**
   ```bash
   git remote -v  # Must show GitHub remote
   ```

2. **GitHub CLI authenticated:**
   ```bash
   gh auth status  # Must show active authentication
   ```

3. **Techspec document:**
   - Location: `docs/features/{feature}/techspec.md` (or user-specified path)
   - Can be generated using `/workflows:tech-spec` slash command
   - Must include: Overview, Requirements, Architecture, Implementation Plan

**If requirements are not met, exit with clear instructions on how to fix them.**

## Workflow

### Step 0: Preflight Checks

Run these checks first. Exit if any fail:

```bash
# 1. Git repository check
git status

# 2. Git remote check (CRITICAL)
git remote -v
# Must have output! If empty, exit with error

# 3. GitHub CLI check
gh --version

# 4. GitHub authentication check
gh auth status
```

**Exit conditions:**
- ❌ Not a git repository → "Run: git init"
- ❌ No git remote → "This skill requires GitHub. Add remote: git remote add origin <url>"
- ❌ No gh CLI → "Install from: https://cli.github.com/"
- ❌ Not authenticated → "Run: gh auth login"

### Step 1: Feature Recognition

Determine which feature to work on:

1. **Extract explicit feature name** from user input
   - Patterns: "{name} feature", "continue {name}", "{name} 시작"

2. **List existing features** if not explicit:
   ```bash
   ls docs/features/
   ```

3. **Match keywords** in user input against feature names

4. **Ask user** if ambiguous:
   - Use `AskUserQuestion` tool
   - Suggest feature name based on input
   - Provide option to enter custom name

**Output:** Feature name in kebab-case (e.g., "stripe-integration")

### Step 2: Techspec Resolution

Find the techspec file using this priority:

1. **User-mentioned file** (HIGHEST priority)
   ```
   User: "docs/my-spec.md를 techspec으로 써줘"
   → Use that file exactly
   ```

2. **Standard location** (case-insensitive)
   ```
   docs/features/{feature}/techspec.md
   docs/features/{feature}/tech-spec.md
   docs/features/{feature}/spec.md
   (also: TechSpec.md, TECHSPEC.md, etc.)
   ```

3. **Auto-search** in docs/ directory

4. **Prompt to create** if not found
   - Suggest using `/workflows:tech-spec`
   - Ask for file path if they have one elsewhere

For detailed techspec handling logic, see `references/techspec-handling.md`.

### Step 3: Branch Management

Check and manage git branch:

1. **Check current branch:**
   ```bash
   git branch --show-current
   ```

2. **If not on feature branch:**
   - Ask: "Switch to feature/{feature}? [Yes/No]"
   - Handle uncommitted changes:
     - Offer: [Commit] [Stash] [Discard] [Cancel]

3. **Create branch if doesn't exist:**
   ```bash
   git checkout -b feature/{feature}
   ```

### Step 4: Mode Determination

Determine whether to INITIALIZE or RESUME:

**Check for existing progress files:**
```bash
test -f docs/features/{feature}/plan.md
test -f docs/features/{feature}/TODO.md
```

- **Both exist** → RESUME Mode
- **Neither exists** → INITIALIZE Mode
- **Only one exists** → Regenerate both (data corruption)

### INITIALIZE Mode

Execute when starting a new feature:

1. **Analyze techspec** (Claude reads and understands)
   - Identify all tasks and dependencies
   - Group into logical phases
   - Estimate effort per task

2. **Map agents automatically**
   - For each task, determine best specialized agent
   - See `references/agent-mapping.md` for mapping logic
   - API endpoints → `backend-api-specialist`
   - React components → `frontend-ui-specialist`
   - Database schema → `database-engineer-specialist`
   - etc.

3. **Generate plan.md**
   - Create execution plan with phases
   - Include agent assignments
   - Specify dependencies and order

4. **Create GitHub Issues (v2)**
   - Create parent feature issue with overview and progress tracking
   - Create sub-issues for each task (linked to parent)
   - Parent labels: `type:parent`, `feature:{name}`, `branch:feature/{name}`
   - Sub-issue labels: `type:sub-issue`, `feature:{name}`, `phase:{n}`, `tdd`
   - Uses Python scripts: `create_parent_issue.py`, `create_sub_issues.py`
   - Handle partial failures (retry failed issues)

5. **Generate TODO.md**
   - Checklist format with phase grouping
   - Synchronized with GitHub Issues
   - Include sync status metadata

6. **Start Phase 1**
   - Ask: "Ready to start Phase 1 (X tasks, ~Y min)?"
   - Launch agents in parallel

### RESUME Mode

Execute when continuing existing feature:

1. **Sync TODO.md ↔ GitHub Issues (v2)**
   - Fetch parent issue + all sub-issues
   - Update TODO.md with current state
   - Update parent issue progress (X/Y tasks complete)
   - Uses Python script: `sync_progress.py`
   - Resolve conflicts (GitHub is source of truth)

2. **Show progress report**
   ```
   📊 Progress: 60% (9/15 tasks)
   ✅ Phase 1-2 complete
   🚧 Phase 3 in progress (1/4)
   ```

3. **Identify next task**
   - Find first uncompleted task
   - Check dependencies are met
   - Determine which phase to continue

4. **Continue execution**
   - Ask: "Continue with Phase X?"
   - Launch agents for pending tasks

### Parallel Execution

Execute multiple tasks simultaneously:

1. **Launch agents in single message**
   - Use multiple `Task` tool calls in ONE message
   - Example: `Task(agent1), Task(agent2), Task(agent3)` in same response

2. **Each agent follows TDD**
   - 🔴 RED: Write failing tests → commit
   - 🟢 GREEN: Implement code → commit
   - 🔵 REFACTOR: Clean up code → commit

3. **Agents close issues**
   - When task completes, close GitHub issue
   - Update TODO.md via sync

4. **Validate → Commit → Sync**
   - Run `npm test` and `npm run build`
   - Commit all changes
   - Sync TODO.md with GitHub

### Exit

Before exiting the skill:

1. **Check uncommitted changes**
   ```bash
   git status
   ```
   - If uncommitted: Ask to commit

2. **Force sync TODO.md ↔ GitHub**
   - Ensure all states are synchronized
   - Resolve any conflicts

3. **Show final progress report**
   ```
   📊 Feature: {name}
   Progress: X% (Y/Z tasks)
   Completed: Phase 1-2
   Remaining: Phase 3-4
   ```

## TDD Enforcement

Every task must follow strict Test-Driven Development:

### 🔴 RED Phase
- Write tests first (before implementation)
- Tests must FAIL when run
- Commit message: `test: Add {component} tests`

### 🟢 GREEN Phase
- Implement minimum code to pass tests
- Tests must PASS when run
- Commit message: `feat: Implement {component}`

### 🔵 REFACTOR Phase
- Improve code quality without changing behavior
- Tests still PASS
- Commit message: `refactor: Clean up {component}`

**Requirement: Each task produces exactly 3 commits (one per phase)**

## File Structure

### Input (User-provided)
```
docs/features/{feature}/
└── techspec.md         # Technical specification
```

### Generated (Skill creates)
```
docs/features/{feature}/
├── plan.md            # Execution plan with agent mapping
└── TODO.md            # Progress checklist (synced with GitHub)
```

### GitHub Issues

**Structure (v2)**: Parent feature issue with sub-issues for each task.

```
Parent Issue:
  Title: [Feature] {feature-name}
  Labels: type:parent, feature:{feature-name}, branch:feature/{feature-name}

Sub-Issues:
  Title: [{feature-name}][Phase N] Task Name
  Labels: type:sub-issue, feature:{feature-name}, phase:{N}, tdd, status:pending
  Linked to parent via GitHub's sub-issue feature
```

**Benefits**:
- Single source of truth for feature progress
- Better organization and visibility
- Progress tracking at feature level
- Less clutter in issues list

## Synchronization Strategy

TODO.md serves as **fast local view**, GitHub Issues as **source of truth**.

**Automatic sync triggers:**
- After each phase completion
- On skill resume (RESUME mode)
- On skill exit
- On user request: "Sync {feature}"

**Conflict resolution:**
- Always trust GitHub Issues over TODO.md
- Auto-fix mismatches
- Log conflicts for user review

## Available Specialized Agents

Claude automatically selects from these agents:

- `backend-api-specialist` - REST/GraphQL API endpoints
- `frontend-ui-specialist` - React components, UI/UX
- `frontend-state-specialist` - State management, data fetching
- `database-engineer-specialist` - Schema, types, data models
- `devops-infrastructure-specialist` - Setup, deployment, CI/CD
- `test-engineer-specialist` - Testing infrastructure
- `security-engineer-specialist` - Security audits
- `frontend-performance-specialist` - Performance optimization

For detailed agent selection logic, see `references/agent-mapping.md`.

## Usage Examples

### Starting New Feature

```
User: "Start stripe-integration feature"

Skill:
  ✅ Git remote configured
  ✅ GitHub authenticated
  ✅ Techspec found: docs/features/stripe-integration/techspec.md

  📖 Analyzing techspec...
  ✅ 12 tasks identified, 4 phases planned
  ✅ Created parent issue #100
  ✅ Created sub-issues #101-#112 (linked to #100)
  ✅ Generated plan.md and TODO.md

  Ready to start Phase 1 (3 tasks, ~30min)?
```

### Resuming Existing Feature

```
User: "Continue toss-integration"

Skill:
  ✅ Feature: toss-integration
  ✅ Branch: feature/toss-integration
  🔄 Syncing with GitHub...

  📊 Progress: 60% (9/15 tasks)
  ✅ Phase 1-2 complete
  🚧 Phase 3 in progress (1/4)

  Continue with Phase 3 Task #2?
```

## Error Handling

For detailed troubleshooting, see project `README.md` (located in skill directory) or references.

**Common issues:**
- "Git remote not configured" → Add remote
- "GitHub not authenticated" → Run `gh auth login`
- "Techspec not found" → Use `/workflows:tech-spec`
- "Sync failed" → Check network and GitHub permissions

## References

This skill includes detailed reference documentation:

- `references/design.md` - Complete technical specification
- `references/agent-mapping.md` - Agent selection logic and mappings
- `references/techspec-handling.md` - Techspec file recognition rules
- `references/examples.md` - Detailed usage scenarios and edge cases

To learn more about specific aspects, read the appropriate reference file.
