#!/usr/bin/env python3
"""
Synchronize GitHub Issues with TODO.md and update parent issue progress.

Usage:
    python sync_progress.py <feature-name> <parent-issue-number> <todo-md-path>

Example:
    python sync_progress.py stripe-integration 100 docs/features/stripe-integration/TODO.md

Output:
    Updates TODO.md file and parent issue, prints sync report to stdout
"""

import sys
import json
import subprocess
import re
from pathlib import Path
from typing import Dict, List, Tuple


def get_github_issues(feature: str) -> Dict:
    """Fetch all issues for a feature from GitHub."""
    env = subprocess.os.environ.copy()
    env.pop('GITHUB_TOKEN', None)

    cmd = [
        'gh', 'issue', 'list',
        '--label', f'feature:{feature}',
        '--json', 'number,state,title,labels',
        '--limit', '150'
    ]

    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        env=env
    )

    if result.returncode != 0:
        raise RuntimeError(f"Failed to fetch issues: {result.stderr}")

    issues = json.loads(result.stdout)

    # Separate parent and sub-issues
    parent = None
    sub_issues = []

    for issue in issues:
        labels = [label['name'] for label in issue['labels']]

        if 'type:parent' in labels:
            parent = issue
        elif 'type:sub-issue' in labels:
            sub_issues.append(issue)

    return {
        'parent': parent,
        'sub_issues': sub_issues,
        'all': issues
    }


def parse_todo_md(todo_path: Path) -> List[Dict]:
    """Parse TODO.md to extract task checkboxes."""
    if not todo_path.exists():
        return []

    content = todo_path.read_text()
    tasks = []

    # Match checkbox lines with issue links
    # Format: - [ ] Task name → [#123](url)
    pattern = r'- \[([ x])\]\s+(.+?)\s+→\s+\[#(\d+)\]'

    for match in re.finditer(pattern, content):
        checked = match.group(1) == 'x'
        task_name = match.group(2).strip()
        issue_number = int(match.group(3))

        tasks.append({
            'name': task_name,
            'issue': issue_number,
            'checked': checked
        })

    return tasks


def update_todo_md(todo_path: Path, sub_issues: List[Dict], parent_number: int, feature: str) -> None:
    """Update TODO.md with current GitHub issues state."""

    # Calculate progress
    total = len(sub_issues)
    completed = sum(1 for issue in sub_issues if issue['state'] == 'closed')
    percentage = round((completed / total) * 100) if total > 0 else 0

    # Group by phase
    phases = {}
    for issue in sub_issues:
        # Extract phase from title: "[feature][Phase N] Task"
        match = re.search(r'\[Phase (\d+)\]', issue['title'])
        phase_num = int(match.group(1)) if match else 0

        if phase_num not in phases:
            phases[phase_num] = []

        phases[phase_num].append(issue)

    # Build TODO.md content
    lines = [
        f"# TODO: {feature}\n",
        f"\n",
        f"**Parent Issue**: [#{parent_number}](https://github.com/{get_repo_name()}/issues/{parent_number})\n",
        f"**Overall Progress**: {percentage}% ({completed}/{total} tasks)\n",
        f"**Branch**: `feature/{feature}`\n",
        f"\n",
        f"---\n",
        f"\n"
    ]

    # Add phases
    for phase_num in sorted(phases.keys()):
        phase_issues = phases[phase_num]
        phase_completed = sum(1 for i in phase_issues if i['state'] == 'closed')

        status_emoji = "✅" if phase_completed == len(phase_issues) else "🚧"

        lines.append(f"## Phase {phase_num} {status_emoji} ({phase_completed}/{len(phase_issues)})\n\n")

        for issue in phase_issues:
            checkbox = "[x]" if issue['state'] == 'closed' else "[ ]"
            task_name = re.sub(r'\[.*?\]\[Phase \d+\]\s*', '', issue['title'])

            lines.append(
                f"- {checkbox} **{task_name}** "
                f"→ [#{issue['number']}](https://github.com/{get_repo_name()}/issues/{issue['number']})\n"
            )

        lines.append("\n")

    # Add footer
    lines.extend([
        "---\n",
        "\n",
        f"**Last Synced**: {get_timestamp()}\n",
        f"**GitHub Issues**: Source of Truth\n",
    ])

    # Write file
    todo_path.write_text("".join(lines))
    print(f"✅ Updated TODO.md: {percentage}% complete ({completed}/{total})", file=sys.stderr)


def update_parent_issue(parent_number: int, sub_issues: List[Dict]) -> None:
    """Update parent issue with current progress."""

    total = len(sub_issues)
    completed = sum(1 for issue in sub_issues if issue['state'] == 'closed')
    percentage = round((completed / total) * 100) if total > 0 else 0

    # Get current issue body
    env = subprocess.os.environ.copy()
    env.pop('GITHUB_TOKEN', None)

    result = subprocess.run(
        ['gh', 'issue', 'view', str(parent_number), '--json', 'body', '--jq', '.body'],
        capture_output=True,
        text=True,
        env=env
    )

    if result.returncode != 0:
        print(f"⚠️  Warning: Could not fetch parent issue: {result.stderr}", file=sys.stderr)
        return

    body = result.stdout

    # Update progress line
    body = re.sub(
        r'\*\*Progress\*\*: \d+/\d+ tasks complete \(\d+%\)',
        f'**Progress**: {completed}/{total} tasks complete ({percentage}%)',
        body
    )

    # Update status line
    status = "✅ Complete" if completed == total else "🚧 In Progress"
    body = re.sub(
        r'\*\*Status\*\*: [^\n]+',
        f'**Status**: {status}',
        body
    )

    # Escape for shell
    escaped_body = body.replace('"', '\\"').replace('$', '\\$').replace('`', '\\`')

    # Update issue
    result = subprocess.run(
        ['gh', 'issue', 'edit', str(parent_number), '--body', escaped_body],
        capture_output=True,
        text=True,
        env=env
    )

    if result.returncode != 0:
        print(f"⚠️  Warning: Could not update parent issue: {result.stderr}", file=sys.stderr)
    else:
        print(f"✅ Updated parent issue #{parent_number}: {percentage}% complete", file=sys.stderr)

    # Close parent if all sub-issues are closed
    if completed == total and total > 0:
        result = subprocess.run(
            ['gh', 'issue', 'close', str(parent_number), '--comment', '✅ All sub-issues complete'],
            capture_output=True,
            text=True,
            env=env
        )

        if result.returncode == 0:
            print(f"✅ Closed parent issue #{parent_number}", file=sys.stderr)


def get_repo_name() -> str:
    """Get current repository name (owner/repo)."""
    result = subprocess.run(
        ['gh', 'repo', 'view', '--json', 'nameWithOwner', '--jq', '.nameWithOwner'],
        capture_output=True,
        text=True
    )

    if result.returncode != 0:
        return "owner/repo"

    return result.stdout.strip()


def get_timestamp() -> str:
    """Get current timestamp."""
    from datetime import datetime
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def main():
    if len(sys.argv) != 4:
        print("Usage: python sync_progress.py <feature-name> <parent-issue-number> <todo-md-path>", file=sys.stderr)
        sys.exit(1)

    feature = sys.argv[1]
    parent_number = int(sys.argv[2])
    todo_path = Path(sys.argv[3])

    try:
        # Fetch GitHub issues
        print(f"🔄 Syncing {feature}...\n", file=sys.stderr)
        github_data = get_github_issues(feature)

        parent = github_data['parent']
        sub_issues = github_data['sub_issues']

        if not parent:
            print(f"⚠️  Warning: Parent issue #{parent_number} not found", file=sys.stderr)

        if not sub_issues:
            print(f"⚠️  Warning: No sub-issues found for {feature}", file=sys.stderr)
            sys.exit(0)

        # Update TODO.md
        update_todo_md(todo_path, sub_issues, parent_number, feature)

        # Update parent issue
        if parent:
            update_parent_issue(parent_number, sub_issues)

        # Print sync report
        total = len(sub_issues)
        completed = sum(1 for i in sub_issues if i['state'] == 'closed')

        print("\n📊 Sync Report:")
        print(f"  Parent: #{parent_number}")
        print(f"  Total tasks: {total}")
        print(f"  Completed: {completed}")
        print(f"  Remaining: {total - completed}")
        print(f"  Progress: {round((completed/total)*100) if total > 0 else 0}%")

    except Exception as e:
        print(f"❌ Error: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc(file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
