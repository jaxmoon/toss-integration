#!/usr/bin/env python3
"""
Close a GitHub issue with TDD phase information.

Usage:
    python close_issue_tdd.py <issue-number> <phase> [--commit <commit-hash>]

Phases:
    RED    - Tests written (failing)
    GREEN  - Implementation complete (passing)
    REFACTOR - Code cleaned up

Example:
    python close_issue_tdd.py 123 RED
    python close_issue_tdd.py 123 GREEN --commit abc1234
    python close_issue_tdd.py 123 REFACTOR --commit def5678

Output:
    Closes the issue with appropriate TDD phase comment
"""

import sys
import argparse
import subprocess
from typing import Optional


PHASE_EMOJIS = {
    'RED': '🔴',
    'GREEN': '🟢',
    'REFACTOR': '🔵',
}

PHASE_MESSAGES = {
    'RED': 'Tests written and failing as expected (TDD Red phase)',
    'GREEN': 'Implementation complete and tests passing (TDD Green phase)',
    'REFACTOR': 'Code refactored and optimized (TDD Refactor phase)',
}


def generate_comment(phase: str, commit_hash: Optional[str] = None) -> str:
    """Generate close comment with TDD phase information."""

    emoji = PHASE_EMOJIS.get(phase.upper(), '✅')
    message = PHASE_MESSAGES.get(phase.upper(), f'{phase} phase complete')

    comment_lines = [
        f"{emoji} **{phase.upper()} Phase Complete**",
        "",
        message,
    ]

    if commit_hash:
        comment_lines.extend([
            "",
            f"**Commit**: {commit_hash}",
        ])

    comment_lines.extend([
        "",
        "---",
        "",
        "**TDD Progress**:",
        f"- [{'x' if phase.upper() == 'RED' else ' '}] 🔴 RED - Write failing tests",
        f"- [{'x' if phase.upper() in ['RED', 'GREEN'] else ' '}] 🟢 GREEN - Implement code",
        f"- [{'x' if phase.upper() == 'REFACTOR' else ' '}] 🔵 REFACTOR - Clean up code",
    ])

    return "\n".join(comment_lines)


def close_issue(issue_number: int, phase: str, commit_hash: Optional[str] = None) -> None:
    """Close issue with TDD phase comment."""

    comment = generate_comment(phase, commit_hash)

    # Escape for shell
    escaped_comment = comment.replace('"', '\\"').replace('$', '\\$').replace('`', '\\`')

    # Close issue with comment
    env = subprocess.os.environ.copy()
    env.pop('GITHUB_TOKEN', None)

    cmd = [
        'gh', 'issue', 'close', str(issue_number),
        '--comment', escaped_comment
    ]

    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        env=env
    )

    if result.returncode != 0:
        raise RuntimeError(f"Failed to close issue: {result.stderr}")

    print(f"✅ Closed issue #{issue_number} ({phase} phase)", file=sys.stderr)


def main():
    parser = argparse.ArgumentParser(
        description='Close GitHub issue with TDD phase information',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python close_issue_tdd.py 123 RED
  python close_issue_tdd.py 123 GREEN --commit abc1234
  python close_issue_tdd.py 123 REFACTOR --commit def5678

TDD Phases:
  RED      - Tests written (failing)
  GREEN    - Implementation complete (passing)
  REFACTOR - Code cleaned up
        """
    )

    parser.add_argument(
        'issue_number',
        type=int,
        help='GitHub issue number to close'
    )

    parser.add_argument(
        'phase',
        choices=['RED', 'GREEN', 'REFACTOR', 'red', 'green', 'refactor'],
        help='TDD phase (RED, GREEN, or REFACTOR)'
    )

    parser.add_argument(
        '--commit',
        help='Commit hash associated with this phase'
    )

    args = parser.parse_args()

    try:
        close_issue(args.issue_number, args.phase.upper(), args.commit)

        # Print confirmation
        emoji = PHASE_EMOJIS[args.phase.upper()]
        print(f"{emoji} Issue #{args.issue_number} closed ({args.phase.upper()} phase)")

    except Exception as e:
        print(f"❌ Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
