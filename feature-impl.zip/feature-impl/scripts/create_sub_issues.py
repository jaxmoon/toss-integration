#!/usr/bin/env python3
"""
Create sub-issues for a feature and link them to parent issue.

Usage:
    python create_sub_issues.py <parent-issue-number> <tasks-json-file>

Tasks JSON format:
    [
      {
        "name": "Task name",
        "phase": 1,
        "agent": "backend-specialist",
        "duration": "20min",
        "files": ["lib/file.ts"],
        "dependencies": [],
        "description": "Task description..."
      },
      ...
    ]

Output:
    Prints JSON mapping {task_name: issue_number} to stdout
"""

import sys
import json
import subprocess
import re
from pathlib import Path
from typing import List, Dict


def escape_for_shell(text: str) -> str:
    """Escape text for safe shell execution."""
    return text.replace('"', '\\"').replace('$', '\\$').replace('`', '\\`')


def get_node_id(issue_number: int) -> str:
    """Get GitHub node ID for an issue."""
    env = subprocess.os.environ.copy()
    env.pop('GITHUB_TOKEN', None)

    result = subprocess.run(
        ['gh', 'issue', 'view', str(issue_number), '--json', 'id', '--jq', '.id'],
        capture_output=True,
        text=True,
        env=env
    )

    if result.returncode != 0:
        raise RuntimeError(f"Failed to get node ID for issue #{issue_number}: {result.stderr}")

    return result.stdout.strip()


def add_sub_issue(parent_number: int, child_number: int) -> None:
    """Link child issue as sub-issue of parent using GraphQL API."""

    # Get node IDs
    parent_id = get_node_id(parent_number)
    child_id = get_node_id(child_number)

    # GraphQL mutation
    mutation = f"""
    mutation {{
      addSubIssue(input: {{
        issueId: "{parent_id}",
        subIssueId: "{child_id}"
      }}) {{
        issue {{ number title }}
        subIssue {{ number title }}
      }}
    }}
    """

    env = subprocess.os.environ.copy()
    env.pop('GITHUB_TOKEN', None)

    result = subprocess.run(
        ['gh', 'api', 'graphql', '-H', 'GraphQL-Features: sub_issues', '-f', f'query={mutation}'],
        capture_output=True,
        text=True,
        env=env
    )

    if result.returncode != 0:
        # Log warning but don't fail (sub-issue feature might not be available)
        print(f"⚠️  Warning: Could not link #{child_number} as sub-issue: {result.stderr}", file=sys.stderr)
    else:
        print(f"  ✅ Linked #{child_number} as sub-issue of #{parent_number}", file=sys.stderr)


def create_issue_body(task: Dict, feature: str, parent_number: int) -> str:
    """Generate issue body from task definition."""

    deps_str = ", ".join(task.get('dependencies', [])) if task.get('dependencies') else 'None'
    files_str = "\n".join([f"- `{f}`" for f in task.get('files', [])])

    body = f"""## Task: {task['name']}

**Parent Issue**: #{parent_number}
**Feature**: {feature}
**Branch**: `feature/{feature}`
**Agent**: {task.get('agent', 'TBD')}
**Phase**: {task.get('phase', 'N/A')}
**Duration**: {task.get('duration', 'TBD')}
**Dependencies**: {deps_str}

---

## Description

{task.get('description', 'No description provided.')}

## Files to Create/Modify

{files_str if files_str else 'TBD'}

---

## TDD Requirements

This task must follow Test-Driven Development methodology:

### 🔴 RED Phase
1. Write failing tests first
2. Commit with message: `test: Add {{component}} tests`

### 🟢 GREEN Phase
1. Implement minimum code to pass tests
2. Commit with message: `feat: Implement {{component}}`

### 🔵 REFACTOR Phase
1. Clean up code while tests still pass
2. Commit with message: `refactor: Clean up {{component}}`

---

**Expected commits**: 3 (one per TDD phase)
"""

    return body


def create_sub_issues(parent_number: int, tasks: List[Dict], feature: str) -> Dict[str, int]:
    """Create all sub-issues and return mapping."""

    issue_map = {}
    env = subprocess.os.environ.copy()
    env.pop('GITHUB_TOKEN', None)

    print(f"📋 Creating {len(tasks)} sub-issues...\n", file=sys.stderr)

    for task in tasks:
        task_name = task['name']
        phase = task.get('phase', 'N/A')

        # Generate issue body
        body = create_issue_body(task, feature, parent_number)
        escaped_body = escape_for_shell(body)

        # Create issue
        cmd = [
            'gh', 'issue', 'create',
            '--title', f'[{feature}][Phase {phase}] {task_name}',
            '--label', 'type:sub-issue',
            '--label', f'feature:{feature}',
            '--label', f'branch:feature/{feature}',
            '--label', f'phase:{phase}',
            '--label', 'tdd',
            '--label', 'status:pending',
            '--body', escaped_body
        ]

        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            env=env
        )

        if result.returncode != 0:
            print(f"❌ Failed to create issue for '{task_name}': {result.stderr}", file=sys.stderr)
            continue

        # Extract issue number
        output = result.stdout.strip()
        match = re.search(r'#(\d+)', output)

        if match:
            child_number = int(match.group(1))
            issue_map[task_name] = child_number
            print(f"  ✅ #{child_number} {task_name}", file=sys.stderr)

            # Link as sub-issue
            try:
                add_sub_issue(parent_number, child_number)
            except Exception as e:
                print(f"  ⚠️  Warning: {e}", file=sys.stderr)
        else:
            print(f"❌ Could not extract issue number from: {output}", file=sys.stderr)

    print(f"\n✅ Created {len(issue_map)} sub-issues\n", file=sys.stderr)

    return issue_map


def main():
    if len(sys.argv) != 3:
        print("Usage: python create_sub_issues.py <parent-issue-number> <tasks-json-file>", file=sys.stderr)
        sys.exit(1)

    parent_number = int(sys.argv[1])
    tasks_file = Path(sys.argv[2])

    if not tasks_file.exists():
        print(f"❌ Tasks file not found: {tasks_file}", file=sys.stderr)
        sys.exit(1)

    try:
        # Load tasks JSON
        tasks = json.loads(tasks_file.read_text())

        # Extract feature name from first task
        feature = tasks[0].get('feature', 'unknown-feature')

        # Create sub-issues
        issue_map = create_sub_issues(parent_number, tasks, feature)

        # Output mapping to stdout (for piping)
        print(json.dumps(issue_map, indent=2))

    except Exception as e:
        print(f"❌ Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
