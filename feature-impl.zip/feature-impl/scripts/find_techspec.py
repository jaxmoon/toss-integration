#!/usr/bin/env python3
"""
Find techspec file for a feature using multiple search strategies.

Usage:
    python find_techspec.py <feature-name> [--path <custom-path>]

Search Priority:
    1. Custom path specified via --path flag
    2. Standard location: docs/features/{feature}/techspec.md
    3. Case-insensitive variants (TechSpec.md, TECHSPEC.md, etc.)
    4. Alternative names (tech-spec.md, spec.md)
    5. Search in docs/ directory
    6. Search in current directory

Example:
    python find_techspec.py stripe-integration
    python find_techspec.py webhook-verification --path docs/webhooks/spec.md

Output:
    Prints the techspec file path to stdout if found, otherwise exits with error
"""

import sys
import argparse
from pathlib import Path
from typing import Optional


def find_techspec(feature: str, custom_path: Optional[str] = None) -> Optional[Path]:
    """
    Find techspec file using prioritized search strategies.

    Args:
        feature: Feature name (kebab-case)
        custom_path: Optional custom path specified by user

    Returns:
        Path to techspec file if found, None otherwise
    """

    # Strategy 1: Custom path (highest priority)
    if custom_path:
        path = Path(custom_path)
        if path.exists() and path.is_file():
            return path
        else:
            print(f"⚠️  Custom path specified but not found: {custom_path}", file=sys.stderr)
            return None

    # Strategy 2: Standard location with variations
    standard_paths = [
        f"docs/features/{feature}/techspec.md",
        f"docs/features/{feature}/TechSpec.md",
        f"docs/features/{feature}/TECHSPEC.md",
        f"docs/features/{feature}/tech-spec.md",
        f"docs/features/{feature}/Tech-Spec.md",
        f"docs/features/{feature}/spec.md",
        f"docs/features/{feature}/Spec.md",
        f"docs/features/{feature}/SPEC.md",
    ]

    for path_str in standard_paths:
        path = Path(path_str)
        if path.exists():
            return path

    # Strategy 3: Alternative feature folder locations
    alternative_paths = [
        f"docs/{feature}/techspec.md",
        f"docs/{feature}/tech-spec.md",
        f"docs/{feature}/spec.md",
        f"docs/{feature}/TechSpec.md",
    ]

    for path_str in alternative_paths:
        path = Path(path_str)
        if path.exists():
            return path

    # Strategy 4: Search in docs/ directory
    docs_dir = Path("docs")
    if docs_dir.exists():
        # Search for files containing feature name
        techspec_variants = [
            "techspec.md",
            "tech-spec.md",
            "TechSpec.md",
            "spec.md",
        ]

        for variant in techspec_variants:
            matches = list(docs_dir.rglob(f"*{feature}*/{variant}"))
            if matches:
                return matches[0]

        # Search for any techspec file in subdirectories
        for variant in techspec_variants:
            matches = list(docs_dir.rglob(variant))
            if matches:
                # Filter by feature name in path
                for match in matches:
                    if feature in str(match).lower():
                        return match

    # Strategy 5: Search in current directory
    current_dir = Path(".")
    for variant in ["techspec.md", "tech-spec.md", "spec.md"]:
        path = current_dir / variant
        if path.exists():
            return path

    return None


def validate_techspec(path: Path) -> bool:
    """
    Validate that the file looks like a techspec document.

    Args:
        path: Path to potential techspec file

    Returns:
        True if file appears to be a valid techspec
    """
    try:
        content = path.read_text().lower()

        # Check for common techspec sections
        required_keywords = ['overview', 'requirement']
        optional_keywords = ['architecture', 'implementation', 'design', 'test']

        has_required = all(keyword in content for keyword in required_keywords)
        has_optional = any(keyword in content for keyword in optional_keywords)

        return has_required or (has_optional and len(content) > 1000)

    except Exception as e:
        print(f"⚠️  Warning: Could not validate {path}: {e}", file=sys.stderr)
        return False


def main():
    parser = argparse.ArgumentParser(
        description='Find techspec file for a feature',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )

    parser.add_argument(
        'feature',
        help='Feature name (kebab-case)'
    )

    parser.add_argument(
        '--path',
        help='Custom path to techspec file'
    )

    parser.add_argument(
        '--validate',
        action='store_true',
        help='Validate that found file is a techspec document'
    )

    parser.add_argument(
        '--verbose',
        action='store_true',
        help='Print search progress'
    )

    args = parser.parse_args()

    try:
        if args.verbose:
            print(f"🔍 Searching for techspec: {args.feature}", file=sys.stderr)

        # Find techspec
        techspec_path = find_techspec(args.feature, args.path)

        if not techspec_path:
            print(f"❌ Techspec not found for feature: {args.feature}", file=sys.stderr)
            print("\nSearched in:", file=sys.stderr)
            print(f"  - docs/features/{args.feature}/techspec.md", file=sys.stderr)
            print(f"  - docs/{args.feature}/techspec.md", file=sys.stderr)
            print(f"  - docs/**/*{args.feature}*/techspec.md", file=sys.stderr)
            print("\nSuggestions:", file=sys.stderr)
            print(f"  1. Create techspec: Use /workflows:tech-spec command", file=sys.stderr)
            print(f"  2. Specify path: --path <techspec-file-path>", file=sys.stderr)
            sys.exit(1)

        # Validate if requested
        if args.validate:
            if not validate_techspec(techspec_path):
                print(f"⚠️  Warning: File may not be a valid techspec: {techspec_path}", file=sys.stderr)

        # Print result
        if args.verbose:
            print(f"✅ Found techspec: {techspec_path}", file=sys.stderr)

        # Output path to stdout (for piping)
        print(techspec_path)

    except Exception as e:
        print(f"❌ Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
