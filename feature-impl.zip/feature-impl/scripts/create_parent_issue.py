#!/usr/bin/env python3
"""
Create a parent GitHub issue for a feature.

Usage:
    python create_parent_issue.py <feature-name> <plan-md-path>

Example:
    python create_parent_issue.py stripe-integration docs/features/stripe-integration/plan.md

Output:
    Prints the parent issue number to stdout
"""

import sys
import json
import subprocess
import re
from pathlib import Path


def parse_plan_md(plan_path: Path) -> dict:
    """Parse plan.md to extract feature metadata."""
    if not plan_path.exists():
        raise FileNotFoundError(f"Plan file not found: {plan_path}")

    content = plan_path.read_text()

    # Extract metadata
    metadata = {}

    # Total tasks
    match = re.search(r'\*\*Total\*\*:\s*(\d+)\s*tasks', content)
    if match:
        metadata['total_tasks'] = int(match.group(1))

    # Estimated time
    match = re.search(r'~([\d.]+)\s*hours', content)
    if match:
        metadata['estimated_time'] = match.group(1) + ' hours'
    else:
        match = re.search(r'~(\d+)\s*min', content)
        if match:
            metadata['estimated_time'] = match.group(1) + ' min'

    # Extract phases
    phases = []
    phase_pattern = r'##\s*Phase\s*(\d+):\s*([^\n]+)'
    for match in re.finditer(phase_pattern, content):
        phase_num = match.group(1)
        phase_name = match.group(2).strip()
        phases.append({'number': phase_num, 'name': phase_name})

    metadata['phases'] = phases

    # Extract overview/summary
    overview_match = re.search(r'##\s*Overview\s*\n\n(.*?)\n\n', content, re.DOTALL)
    if overview_match:
        metadata['summary'] = overview_match.group(1).strip()
    else:
        metadata['summary'] = f"Implementation of {metadata.get('feature', 'feature')}"

    return metadata


def escape_for_shell(text: str) -> str:
    """Escape text for safe shell execution."""
    return text.replace('"', '\\"').replace('$', '\\$').replace('`', '\\`')


def create_parent_issue(feature: str, metadata: dict) -> int:
    """Create parent issue and return issue number."""

    # Build issue body
    phases_section = "\n".join([
        f"### Phase {p['number']}: {p['name']}"
        for p in metadata.get('phases', [])
    ])

    body = f"""# {feature}

**Status**: 🚧 In Progress
**Progress**: 0/{metadata.get('total_tasks', 'N')} tasks complete (0%)
**Estimated Time**: {metadata.get('estimated_time', 'TBD')}

## Overview

{metadata.get('summary', f'Implementation of {feature} feature')}

## Documents

- 📋 Techspec: `docs/features/{feature}/techspec.md`
- 📝 Plan: `docs/features/{feature}/plan.md`
- ✅ Progress: `docs/features/{feature}/TODO.md`

## Phases

{phases_section}

## Branch

`feature/{feature}`

---

**Sub-issues**: Will be created for each task in the plan.

**TDD Methodology**: Each sub-issue follows Red-Green-Refactor cycle.
"""

    # Escape body for shell
    escaped_body = escape_for_shell(body)

    # Create issue using gh CLI
    cmd = [
        'gh', 'issue', 'create',
        '--title', f'[Feature] {feature}',
        '--label', 'type:parent',
        '--label', f'feature:{feature}',
        '--label', f'branch:feature/{feature}',
        '--body', escaped_body
    ]

    # Unset GITHUB_TOKEN to avoid conflicts
    env = subprocess.os.environ.copy()
    env.pop('GITHUB_TOKEN', None)

    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        env=env
    )

    if result.returncode != 0:
        raise RuntimeError(f"Failed to create issue: {result.stderr}")

    # Extract issue number from output
    output = result.stdout.strip()
    match = re.search(r'#(\d+)', output)

    if not match:
        raise RuntimeError(f"Could not extract issue number from: {output}")

    issue_number = int(match.group(1))

    print(f"✅ Created parent issue: #{issue_number}", file=sys.stderr)

    return issue_number


def main():
    if len(sys.argv) != 3:
        print("Usage: python create_parent_issue.py <feature-name> <plan-md-path>", file=sys.stderr)
        sys.exit(1)

    feature = sys.argv[1]
    plan_path = Path(sys.argv[2])

    try:
        # Parse plan.md
        metadata = parse_plan_md(plan_path)
        metadata['feature'] = feature

        # Create parent issue
        parent_number = create_parent_issue(feature, metadata)

        # Output issue number to stdout (for piping)
        print(parent_number)

    except Exception as e:
        print(f"❌ Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
